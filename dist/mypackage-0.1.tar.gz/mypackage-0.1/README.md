# mypackage
This package was built as an example of how to publish your own python package

## Building the package locally
'python setup.py sdist'